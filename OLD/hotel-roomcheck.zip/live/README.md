# 호텔 룸첵 사이트 - 에이전트 API 통합

**프로젝트 상태:** ✅ 완료  
**최종 업데이트:** 2026-07-24  
**버전:** 1.0

---

## 📌 프로젝트 개요

에이전트 부계정 자동채우기 기능이 완전히 구현되었습니다.

- 🔐 **부계정 로그인**: 외부 API 연동
- 🏨 **호텔 API**: 목록 및 상세 조회
- 🏢 **에이전시 API**: 목록 및 상세 조회  
- ✨ **자동채우기**: 폼 필드 자동 입력
- 🌍 **다국어**: 한글/영문/태국어

---

## 📁 폴더 구조

```
/home/claude/live/
├── README.md                    # 이 파일
├── .env                         # 프로덕션 설정
├── .env.local                   # 개발 설정 (git 제외)
├── mock-api-server.php         # Mock API 서버
│
├── docs/                        # 📚 프로젝트 문서
│   ├── PROJECT_COMPLETION_SUMMARY.md    # 최종 완료 보고서
│   ├── API_INTEGRATION_TEST_RESULTS.md  # 테스트 결과
│   ├── DEPLOYMENT_METHODS.md            # 배포 방법 가이드
│   ├── API_DOCUMENTATION.md             # API 문서
│   └── TROUBLESHOOTING.md               # 문제 해결 가이드
│
├── public/
│   ├── index.php                # 프론트 컨트롤러
│   ├── login.html               # 로그인 페이지
│   ├── agent.html               # 에이전트 페이지
│   ├── app.js                   # 메인 로직
│   ├── i18n.js                  # 다국어 지원
│   ├── style.css                # 스타일
│   └── logo.png
│
├── src/
│   ├── router.php               # API 라우팅
│   ├── agency.php               # 부계정/에이전시 API
│   ├── hotel.php                # 호텔 API
│   ├── lib.php                  # 공용 헬퍼
│   ├── db.php                   # 데이터베이스
│   ├── events.php               # 이벤트
│   ├── digest.php               # 다이제스트
│   └── telegram.php             # 텔레그램 봇
│
├── .github/
│   └── workflows/
│       └── deploy.yml           # GitHub Actions 배포
│
└── scripts/
    ├── deploy.sh                # SSH 배포 스크립트
    └── backup.sh                # 백업 스크립트
```

---

## 🚀 빠른 시작

### 로컬 개발 환경

```bash
# 1. Mock API 서버 시작 (port 8011)
php -S localhost:8011 mock-api-server.php &

# 2. 앱 서버 시작 (port 8010)
php -S localhost:8010 -t public public/index.php &

# 3. 접속
# 부계정: nirvana_sub1
# 비밀번호: password123
```

### 프로덕션 배포

```bash
# 방법 1: GitHub Actions (자동)
git push origin main

# 방법 2: SSH 배포
./scripts/deploy.sh

# 방법 3: 수동 배포
scp -r . user@server:/home/yourapp/live
```

자세한 내용은 `docs/DEPLOYMENT_METHODS.md` 참고

---

## 📚 문서 목록

| 문서 | 용도 |
|------|------|
| `docs/PROJECT_COMPLETION_SUMMARY.md` | 전체 프로젝트 완료 보고서 |
| `docs/API_INTEGRATION_TEST_RESULTS.md` | API 테스트 결과 |
| `docs/API_DOCUMENTATION.md` | API 엔드포인트 문서 |
| `docs/DEPLOYMENT_METHODS.md` | 5가지 배포 방법 |
| `docs/TROUBLESHOOTING.md` | 문제 해결 가이드 |

---

## 🧪 테스트

### Curl 테스트

```bash
# 부계정 로그인
curl -X POST http://localhost:8010/api/agency-login \
  -H "Content-Type: application/json" \
  -d '{"login_id":"nirvana_sub1","password":"password123"}'

# 호텔 목록
curl http://localhost:8010/api/hotels

# 에이전시 목록
curl http://localhost:8010/api/agencies
```

자세한 테스트 방법은 `docs/API_INTEGRATION_TEST_RESULTS.md` 참고

---

## ⚙️ 환경 설정

### .env (프로덕션)
```
AGENCY_API_BASE=https://nirvana835.mycafe24.com
HOTEL_API_BASE=https://nirvana835.mycafe24.com
```

### .env.local (개발)
```
AGENCY_API_BASE=http://localhost:8011
HOTEL_API_BASE=http://localhost:8011
```

---

## 🔐 보안

✅ 비밀번호 로깅 금지  
✅ 세션 기반 인증  
✅ HTTPS 권장 (프로덕션)  
✅ SSL 인증서 필수  

---

## 📞 문제 해결

### 문제: "agency_disabled" 에러
**해결:** `.env` 파일에서 `AGENCY_API_BASE` 확인

### 문제: cURL errno 56
**해결:** 프로덕션 배포 후 실제 API 사용

자세한 내용은 `docs/TROUBLESHOOTING.md` 참고

---

## 📝 기술 스택

- **Backend:** PHP 8.4 (순수 PHP, Framework 없음)
- **Frontend:** HTML5, CSS3, Vanilla JavaScript
- **Database:** MySQL/MariaDB
- **API:** RESTful (JSON)
- **Authentication:** Session-based
- **Deployment:** Git, SSH, Docker (선택)

---

## 🎯 다음 단계

1. ✅ 로컬 테스트 완료
2. 🚀 프로덕션 배포
3. 🧪 사용자 수용 테스트 (UAT)
4. 📊 성능 모니터링

배포 방법은 `docs/DEPLOYMENT_METHODS.md` 참고

---

## 📄 라이선스

Internal Project

---

**작성자:** Claude  
**마지막 업데이트:** 2026-07-24  
**상태:** 프로덕션 배포 준비 완료 ✅
