# API 문서

**작성일:** 2026-07-24  
**상태:** ✅ 완료  
**버전:** 1.0

---

## 📋 개요

호텔 룸첵 사이트의 모든 API 엔드포인트 상세 문서입니다.

**기본 URL:** `http://localhost:8010` (개발) 또는 `https://your-domain.com` (프로덕션)

---

## 🔐 인증 (Authentication)

### 세션 기반 인증
모든 API는 PHP 세션 기반 인증을 사용합니다.

```php
session_start();
if (!isset($_SESSION['user'])) {
    http_response_code(401);
    echo json_encode(['error' => 'unauthorized']);
    exit;
}
```

### 로그인 필수
- 부계정 로그인 API (`/api/agency-login`) 제외
- 나머지 모든 API는 세션 필수

---

## 📚 API 엔드포인트

---

## 1️⃣ 부계정 로그인

### 요청

**메서드:** `POST`  
**URL:** `/api/agency-login`  
**Content-Type:** `application/json`

**요청 본문:**
```json
{
  "login_id": "nirvana_sub1",
  "password": "password123"
}
```

**파라미터:**
| 필드 | 타입 | 필수 | 설명 |
|-----|------|------|------|
| login_id | string | ✅ | 부계정 아이디 |
| password | string | ✅ | 부계정 비밀번호 |

### 응답

**성공 (200)**
```json
{
  "ok": true,
  "user": {
    "id": 3,
    "name": "너비나서브1",
    "email": "agency-2@agency.local",
    "role": "agent",
    "status": "approved",
    "lang": "ko",
    "tg": false,
    "phone": "",
    "nickname": "",
    "bank_account": "",
    "region": null,
    "super": false,
    "ext": true,
    "off_days": {
      "dates": [],
      "weekdays": [],
      "work_overrides": []
    },
    "agency": {
      "idx": 2,
      "parent_idx": null,
      "kind": "travel",
      "login_id": "nirvana_sub1",
      "nickname": "nirvana_sub1"
    }
  }
}
```

**실패 - 잘못된 자격증명 (401)**
```json
{
  "error": "bad_credentials"
}
```

**실패 - 외부 API 미설정 (503)**
```json
{
  "error": "agency_disabled"
}
```

### Curl 테스트

```bash
curl -X POST http://localhost:8010/api/agency-login \
  -H "Content-Type: application/json" \
  -d '{"login_id":"nirvana_sub1","password":"password123"}' \
  -c /tmp/cookies.txt
```

### 구현 파일
- `src/agency.php` (line 1-228)
- `src/router.php` (line 78)

---

## 2️⃣ 호텔 목록 조회

### 요청

**메서드:** `GET`  
**URL:** `/api/hotels`  
**인증:** 세션 필수 ✅

**쿼리 파라미터:** 없음

### 응답

**성공 (200)**
```json
{
  "ok": true,
  "hotels": [
    {
      "idx": 1,
      "name": "The Nirvana",
      "main_hotel_yn": "Y",
      "area": "Bangkok",
      "address": "..."
    },
    {
      "idx": 2,
      "name": "Test Hotel",
      "main_hotel_yn": "N",
      "area": "Krabi",
      "address": "..."
    },
    {
      "idx": 3,
      "name": "Dr Travel",
      "main_hotel_yn": "N",
      "area": "Bangkok",
      "address": "..."
    }
  ]
}
```

**실패 - 미인증 (401)**
```json
{
  "error": "unauthorized"
}
```

### Curl 테스트

```bash
# 먼저 로그인하여 세션 확보
curl -X POST http://localhost:8010/api/agency-login \
  -H "Content-Type: application/json" \
  -d '{"login_id":"nirvana_sub1","password":"password123"}' \
  -c /tmp/cookies.txt

# 호텔 목록 조회
curl http://localhost:8010/api/hotels \
  -b /tmp/cookies.txt
```

### 구현 파일
- `src/hotel.php` (호텔 관련 함수)
- `src/router.php` (line 485-516)

---

## 3️⃣ 호텔 상세 조회

### 요청

**메서드:** `GET`  
**URL:** `/api/hotels/{idx}`  
**인증:** 세션 필수 ✅

**URL 파라미터:**
| 파라미터 | 타입 | 필수 | 설명 |
|---------|------|------|------|
| idx | integer | ✅ | 호텔 ID |

### 응답

**성공 (200)**
```json
{
  "ok": true,
  "hotel": {
    "hotel": {
      "idx": 1,
      "name": "The Nirvana",
      "main_hotel_yn": "Y"
    },
    "room_types": [
      {
        "idx": 101,
        "name": "디럭스룸",
        "code": "DELUXE"
      },
      {
        "idx": 102,
        "name": "스위트룸",
        "code": "SUITE"
      }
    ],
    "facilities": [
      "WiFi",
      "Pool",
      "Restaurant"
    ]
  }
}
```

**실패 - 호텔 없음 (404)**
```json
{
  "error": "not_found"
}
```

### Curl 테스트

```bash
curl http://localhost:8010/api/hotels/1 \
  -b /tmp/cookies.txt
```

---

## 4️⃣ 에이전시 목록 조회

### 요청

**메서드:** `GET`  
**URL:** `/api/agencies`  
**인증:** 세션 필수 ✅

### 응답

**성공 (200)**
```json
{
  "ok": true,
  "agencies": [
    {
      "idx": 1,
      "name": "Awesome Agency",
      "type": "travel",
      "level": 1
    },
    {
      "idx": 2,
      "name": "The Nirvana",
      "type": "travel",
      "level": 1
    }
  ]
}
```

### Curl 테스트

```bash
curl http://localhost:8010/api/agencies \
  -b /tmp/cookies.txt
```

### 구현 파일
- `src/agency.php` (agencyListRequest 함수)
- `src/router.php` (라우팅)

---

## 5️⃣ 에이전시 상세 조회

### 요청

**메서드:** `GET`  
**URL:** `/api/agencies/{idx}`  
**인증:** 세션 필수 ✅

**URL 파라미터:**
| 파라미터 | 타입 | 필수 | 설명 |
|---------|------|------|------|
| idx | integer | ✅ | 에이전시 ID |

### 응답

**성공 (200)**
```json
{
  "ok": true,
  "agency": {
    "agency": {
      "idx": 1,
      "name": "Awesome Agency",
      "type": "travel",
      "level": 1,
      "phone": "02-1234-5678",
      "email": "info@awesome.com"
    },
    "managers": [
      {
        "name": "홍길동",
        "position": "대표",
        "phone": "010-1111-1111"
      }
    ],
    "bank_accounts": [
      {
        "bank": "국민은행",
        "account": "123-456-789012",
        "holder": "Awesome Agency"
      }
    ],
    "contracts": [
      {
        "idx": 101,
        "name": "계약1",
        "status": "active"
      }
    ]
  }
}
```

**실패 - 에이전시 없음 (404)**
```json
{
  "error": "not_found"
}
```

### Curl 테스트

```bash
curl http://localhost:8010/api/agencies/1 \
  -b /tmp/cookies.txt
```

### 구현 파일
- `src/agency.php` (agencyDetailRequest 함수)
- `src/router.php` (라우팅)

---

## 🔍 HTTP 상태 코드

| 코드 | 의미 | 설명 |
|------|------|------|
| 200 | OK | 요청 성공 |
| 400 | Bad Request | 잘못된 요청 파라미터 |
| 401 | Unauthorized | 미인증 (로그인 필요) |
| 404 | Not Found | 리소스 없음 |
| 500 | Internal Server Error | 서버 에러 |
| 503 | Service Unavailable | 외부 API 사용 불가 |

---

## 📝 에러 응답 형식

모든 에러는 다음 형식으로 반환됩니다:

```json
{
  "error": "error_code"
}
```

**에러 코드 목록:**
| 코드 | HTTP | 설명 |
|------|------|------|
| bad_credentials | 401 | 잘못된 아이디/비밀번호 |
| unauthorized | 401 | 세션 없음 |
| not_found | 404 | 리소스 없음 |
| agency_disabled | 503 | 외부 API 미설정 |
| server_error | 500 | 서버 에러 |

---

## 🧪 테스트 계정

### Mock 서버 테스트 계정
| 아이디 | 비밀번호 | 이름 |
|-------|---------|------|
| nirvana_sub1 | password123 | 너비나서브1 |
| sub1 | password123 | 서브1 |
| test1234 | password123 | test |
| test2 | password123 | 이지성 |

---

## ⚙️ 환경 설정

### .env (프로덕션)
```
AGENCY_API_BASE=https://nirvana835.mycafe24.com
AGENCY_API_PATH=/api2/agency-sub-accounts/login
AGENCY_API_MODE=json
AGENCY_API_TIMEOUT=10
AGENCY_API_UA=RoomcheckServer/1.0

HOTEL_API_BASE=https://nirvana835.mycafe24.com
HOTEL_API_PATH=/api2/hotels
HOTEL_API_TIMEOUT=10
HOTEL_API_UA=RoomcheckServer/1.0
```

### .env.local (개발/테스트)
```
AGENCY_API_BASE=http://localhost:8011
HOTEL_API_BASE=http://localhost:8011
```

---

## 🚀 빠른 테스트 명령어

### 전체 테스트 스크립트

```bash
#!/bin/bash

echo "🔐 1. 부계정 로그인..."
curl -X POST http://localhost:8010/api/agency-login \
  -H "Content-Type: application/json" \
  -d '{"login_id":"nirvana_sub1","password":"password123"}' \
  -c /tmp/cookies.txt

echo -e "\n\n🏨 2. 호텔 목록..."
curl http://localhost:8010/api/hotels -b /tmp/cookies.txt

echo -e "\n\n🏨 3. 호텔 상세 (ID=1)..."
curl http://localhost:8010/api/hotels/1 -b /tmp/cookies.txt

echo -e "\n\n🏢 4. 에이전시 목록..."
curl http://localhost:8010/api/agencies -b /tmp/cookies.txt

echo -e "\n\n🏢 5. 에이전시 상세 (ID=1)..."
curl http://localhost:8010/api/agencies/1 -b /tmp/cookies.txt
```

---

## 🔐 보안 고려사항

### API 키 보호
- 프론트엔드는 API 키 사용 금지
- 모든 인증은 서버에서 처리
- 클라이언트는 세션 쿠키만 사용

### HTTPS 필수
- 프로덕션: 반드시 HTTPS 사용
- 비밀번호는 TLS로 암호화된 채널로만 전송

### 비밀번호 안전
- 모든 비밀번호 로깅 금지
- 메모리에 로드된 비밀번호는 사용 후 즉시 제거
- #[\SensitiveParameter] PHP 속성 사용

---

## 📞 문제 해결

### "agency_disabled" 에러
**원인:** 외부 API 베이스 URL이 설정되지 않음

**해결:**
```bash
# .env 파일 확인
cat .env | grep AGENCY_API_BASE

# 또는 .env.local 확인
cat .env.local | grep AGENCY_API_BASE
```

### "unauthorized" 에러
**원인:** 로그인하지 않음

**해결:** 먼저 /api/agency-login으로 로그인

### "bad_credentials" 에러
**원인:** 잘못된 아이디/비밀번호

**해결:**
- 테스트 계정 확인
- 아이디/비밀번호 재확인

### "not_found" 에러
**원인:** 존재하지 않는 리소스 ID

**해결:** 유효한 리소스 ID 확인

---

**작성자:** Claude  
**최종 업데이트:** 2026-07-24  
**상태:** ✅ 완료
