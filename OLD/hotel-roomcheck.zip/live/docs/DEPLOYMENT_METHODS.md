# 배포 방법 가이드 - 5가지 방법

**작성일:** 2026-07-24  
**상태:** ✅ 완료

---

## 📋 개요

Claude Shell 시간 제한 문제를 우회하기 위한 5가지 배포 방법을 제공합니다.

---

## 방법 1️⃣ GitHub Actions (자동 배포) ✅ 추천

### 장점
- 완전히 자동화됨
- 시간 제한 없음
- Git push만으로 배포
- 무료 (공개 저장소)

### 설정 방법

#### 1. GitHub 저장소 설정

```bash
# 저장소 생성 및 로컬 git 초기화
git init
git add .
git commit -m "Initial commit: Hotel Roomcheck with Agency API"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/hotel-roomcheck.git
git push -u origin main
```

#### 2. GitHub Actions 워크플로우 생성

`.github/workflows/deploy.yml` 파일을 생성합니다:

```yaml
name: Deploy to Production

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - name: Checkout code
      uses: actions/checkout@v3
    
    - name: Deploy via SSH
      uses: appleboy/ssh-action@master
      with:
        host: ${{ secrets.SSH_HOST }}
        username: ${{ secrets.SSH_USER }}
        key: ${{ secrets.SSH_KEY }}
        script: |
          cd /home/yourapp/live
          git pull origin main
          # 필요시 파일 권한 변경
          chmod -R 755 .
          # 필요시 캐시 초기화
          rm -rf /tmp/cache/*
```

#### 3. GitHub Secrets 설정

GitHub 저장소 → Settings → Secrets → "New repository secret"

필요한 secrets:
- `SSH_HOST`: 서버 주소 (예: example.com)
- `SSH_USER`: SSH 사용자명
- `SSH_KEY`: SSH 개인키 (한 줄 텍스트)

#### 4. 배포 실행

```bash
# 변경 사항 커밋 후 push
git add .
git commit -m "Update: Add new features"
git push origin main
# 자동으로 GitHub Actions 실행 → 서버에 배포
```

### SSH 키 생성 (처음 한 번만)

```bash
# 새로운 SSH 키 생성
ssh-keygen -t rsa -b 4096 -f deploy_key -N ""

# 공개키를 서버에 추가
cat deploy_key.pub >> ~/.ssh/authorized_keys

# GitHub Secrets에 개인키 추가
cat deploy_key | tr '\n' '|'  # 한 줄 텍스트로 변환 후 복사
```

---

## 방법 2️⃣ SSH SCP 배포 (스크립트 기반)

### 장점
- 언제든 배포 가능
- 선택적 파일 배포
- 빠른 배포 속도

### 배포 스크립트

`scripts/deploy.sh` 파일:

```bash
#!/bin/bash

# 배포 설정
REMOTE_USER="your_username"
REMOTE_HOST="your-domain.com"
REMOTE_PATH="/home/yourapp/live"
LOCAL_PATH="$(pwd)"

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}🚀 배포 시작...${NC}"

# SSH 연결 테스트
if ! ssh -o ConnectTimeout=5 ${REMOTE_USER}@${REMOTE_HOST} "echo OK" > /dev/null 2>&1; then
    echo -e "${RED}❌ 서버에 연결할 수 없습니다${NC}"
    exit 1
fi

# 파일 업로드
echo -e "${YELLOW}📤 파일 업로드 중...${NC}"
scp -r ${LOCAL_PATH}/src ${REMOTE_USER}@${REMOTE_HOST}:${REMOTE_PATH}/
scp -r ${LOCAL_PATH}/public ${REMOTE_USER}@${REMOTE_HOST}:${REMOTE_PATH}/
scp -r ${LOCAL_PATH}/docs ${REMOTE_USER}@${REMOTE_HOST}:${REMOTE_PATH}/
scp ${LOCAL_PATH}/.env ${REMOTE_USER}@${REMOTE_HOST}:${REMOTE_PATH}/ 2>/dev/null || true

# 원격 서버에서 실행
echo -e "${YELLOW}🔧 서버 설정 중...${NC}"
ssh ${REMOTE_USER}@${REMOTE_HOST} "
    cd ${REMOTE_PATH}
    chmod -R 755 .
    chmod 600 .env
    # 캐시 초기화
    find . -name '__pycache__' -type d -exec rm -rf {} + 2>/dev/null || true
"

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ 배포 완료!${NC}"
else
    echo -e "${RED}❌ 배포 실패${NC}"
    exit 1
fi
```

### 사용 방법

```bash
# 스크립트 실행 권한 부여
chmod +x scripts/deploy.sh

# 배포 실행
./scripts/deploy.sh
```

---

## 방법 3️⃣ Docker를 이용한 배포

### 장점
- 환경 격리
- 어디서나 동일하게 실행
- 버전 관리 용이

### Dockerfile 작성

`Dockerfile`:

```dockerfile
FROM php:8.4-apache

# 필수 PHP 확장 설치
RUN docker-php-ext-install mysqli json

# Apache mod_rewrite 활성화
RUN a2enmod rewrite

# 작업 디렉토리 설정
WORKDIR /var/www/html

# 소스 코드 복사
COPY . .

# 권한 설정
RUN chmod -R 755 . && \
    chown -R www-data:www-data .

# 환경 변수 설정
ENV AGENCY_API_BASE=https://nirvana835.mycafe24.com
ENV HOTEL_API_BASE=https://nirvana835.mycafe24.com
ENV AGENCY_API_TIMEOUT=10

# 포트 노출
EXPOSE 80

# Apache 시작
CMD ["apache2-foreground"]
```

### Docker Compose 설정

`docker-compose.yml`:

```yaml
version: '3.8'

services:
  app:
    build: .
    container_name: hotel-roomcheck
    ports:
      - "8010:80"
    environment:
      - AGENCY_API_BASE=https://nirvana835.mycafe24.com
      - HOTEL_API_BASE=https://nirvana835.mycafe24.com
      - AGENCY_API_TIMEOUT=10
    volumes:
      - .:/var/www/html
    restart: always
```

### 배포 실행

```bash
# 이미지 빌드
docker build -t hotel-roomcheck .

# 컨테이너 실행
docker run -p 8010:80 hotel-roomcheck

# 또는 Docker Compose 사용
docker-compose up -d
```

---

## 방법 4️⃣ FTP/SFTP를 이용한 배포

### 장점
- 호스팅 제공자에서 일반적으로 지원
- GUI 도구 사용 가능
- 초보자 친화적

### FTP 클라이언트 설정

#### FileZilla 사용 예시

1. **서버 설정**
   - 호스트: ftp.your-domain.com
   - 사용자명: your_ftp_username
   - 비밀번호: your_ftp_password
   - 포트: 21 (SFTP의 경우 22)

2. **파일 업로드**
   - 로컬: `/home/claude/live/`
   - 원격: `/public_html/` 또는 `/home/yourapp/live/`
   - 드래그&드롭으로 업로드

3. **파일 권한 설정**
   - 폴더: 755
   - 파일: 644
   - .env: 600

### 명령줄 SFTP 배포

```bash
#!/bin/bash

# SFTP 배포 스크립트
SFTP_SERVER="your-domain.com"
SFTP_USER="sftp_username"
SFTP_PASSWORD="sftp_password"
REMOTE_PATH="/public_html/"

# expect를 이용한 자동화 (암호 자동 입력)
expect << EOF
spawn sftp ${SFTP_USER}@${SFTP_SERVER}
expect "password:"
send "${SFTP_PASSWORD}\r"
expect "sftp>"

# 디렉토리 생성 및 파일 업로드
send "mkdir -p src public docs\r"
expect "sftp>"

send "put -r src/* ${REMOTE_PATH}src/\r"
expect "sftp>"

send "put -r public/* ${REMOTE_PATH}public/\r"
expect "sftp>"

send "put -r docs/* ${REMOTE_PATH}docs/\r"
expect "sftp>"

send "put .env ${REMOTE_PATH}\r"
expect "sftp>"

send "chmod 755 ${REMOTE_PATH}*\r"
expect "sftp>"

send "exit\r"
expect eof
EOF
```

---

## 방법 5️⃣ 호스팅 제공자 패널 (웹UI)

### 장점
- 기술 지식 불필요
- 직관적인 UI
- 대부분의 호스팅에서 지원

### 일반적인 호스팅 패널 사용법

#### cPanel (GoDaddy, Bluehost, HostGator 등)

1. **File Manager 접속**
   - cPanel 로그인
   - "File Manager" 클릭
   - `/public_html/` 디렉토리 이동

2. **파일 업로드**
   - "Upload" 버튼 클릭
   - 파일/폴더 선택
   - 업로드 시작

3. **설정**
   - 접근 권한 설정 (아이콘 우클릭 → Permissions)
   - 폴더: 755 / 파일: 644

#### Plesk (더 고급 호스팅)

1. **File Manager 접속**
   - Plesk 대시보드 로그인
   - "File Manager" 클릭

2. **배포 프로세스**
   - 모든 파일 선택
   - "Upload" 클릭
   - 자동으로 배포 완료

---

## 배포 후 확인 사항

### 환경 설정 확인
```bash
# SSH로 서버 접속
ssh user@your-domain.com

# 설정 파일 확인
cat /home/yourapp/live/.env
```

### 파일 권한 확인
```bash
ls -la /home/yourapp/live/

# 예상 결과:
# drwxr-xr-x  src/
# drwxr-xr-x  public/
# -rw-r--r--  .env
# -rw-r--r--  README.md
```

### API 테스트
```bash
# 부계정 로그인 테스트
curl -X POST https://your-domain.com/api/agency-login \
  -H "Content-Type: application/json" \
  -d '{"login_id":"nirvana_sub1","password":"password123"}'

# 호텔 목록 조회
curl https://your-domain.com/api/hotels
```

---

## 배포 방법 비교

| 항목 | GitHub Actions | SSH/SCP | Docker | FTP | 호스팅 패널 |
|------|---|---|---|---|---|
| 자동화 | ✅ | ⭕ | ✅ | ❌ | ❌ |
| 무료 | ✅ | ✅ | ✅ | ✅ | ⭕ |
| 속도 | 2-5분 | 1-2분 | 3-5분 | 5-10분 | 2-3분 |
| 기술 난이도 | 중상 | 중 | 중상 | 하 | 하 |
| 추천 대상 | 팀 프로젝트 | 개인 프로젝트 | 규모 있는 프로젝트 | 호스팅 사용자 | 초보자 |

---

## 🔐 보안 주의사항

### .env 파일 보호
```bash
# SSH로 배포한 경우
chmod 600 .env

# .gitignore에 추가
echo ".env" >> .gitignore
echo ".env.local" >> .gitignore
```

### 비밀번호 관리
- 배포용 SSH 키는 별도 관리
- GitHub Secrets 사용 (절대 Repo에 커밋하지 않기)
- FTP 비밀번호는 안전한 곳에만 저장

### SSL/HTTPS 필수
- 프로덕션: Let's Encrypt 이용한 SSL 인증서 설치
- 비밀번호 전송은 반드시 HTTPS 사용

---

## 🆘 문제 해결

### "Connection refused" 에러
- SSH 서버가 실행 중인지 확인
- 방화벽 설정 확인
- SSH 포트(기본값 22) 개방 확인

### "Permission denied" 에러
```bash
# 파일 권한 재설정
chmod -R 755 .
chmod 600 .env
```

### 배포 후 "agency_disabled" 에러
- .env 파일이 올바르게 배포되었는지 확인
- 외부 API 주소가 올바른지 확인
- 방화벽이 HTTPS 443 포트를 차단하지 않는지 확인

---

**작성자:** Claude  
**최종 업데이트:** 2026-07-24  
**상태:** ✅ 완료
