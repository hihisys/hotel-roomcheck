# 문제 해결 가이드

**작성일:** 2026-07-24  
**상태:** ✅ 완료

---

## 📋 개요

호텔 룸첵 사이트 운영 중 발생할 수 있는 문제들과 해결 방법을 정리했습니다.

---

## 🔴 로그인 관련 문제

---

### 문제 1: "아이디 또는 비밀번호가 일치하지 않습니다" 에러

#### 증상
부계정으로 로그인할 때 자격증명 에러 (401)

#### 원인
1. 아이디/비밀번호 오타
2. 테스트 계정이 아님
3. 외부 API가 응답하지 않음

#### 해결 방법

**Step 1: 테스트 계정 확인**

```bash
# 개발 환경에서 테스트
php -S localhost:8011 mock-api-server.php &
```

테스트 계정:
- 아이디: `nirvana_sub1`
- 비밀번호: `password123`

**Step 2: Curl로 직접 테스트**

```bash
curl -X POST http://localhost:8010/api/agency-login \
  -H "Content-Type: application/json" \
  -d '{"login_id":"nirvana_sub1","password":"password123"}'
```

**Step 3: Mock API 서버 확인**

```bash
# Mock API 서버가 실행 중인지 확인
curl http://localhost:8011/api2/agency-sub-accounts/login \
  -X POST \
  -H "Content-Type: application/json" \
  -d '{"login_id":"nirvana_sub1","password":"password123"}'
```

**Step 4: 환경 변수 확인**

```bash
# .env.local 파일이 있는지 확인
ls -la .env*

# AGENCY_API_BASE 값 확인
grep AGENCY_API_BASE .env*
```

---

### 문제 2: "agency_disabled" 에러 (503)

#### 증상
부계정은 정확한데 503 Service Unavailable

#### 원인
1. .env 파일이 없거나 AGENCY_API_BASE가 설정되지 않음
2. 외부 API에 연결할 수 없음 (프로덕션)
3. Mock API 서버가 실행 중이 아님 (개발)

#### 해결 방법

**개발 환경:**

```bash
# 1. Mock API 서버 시작
php -S localhost:8011 mock-api-server.php &

# 2. .env.local 파일 생성
cat > .env.local << EOF
AGENCY_API_BASE=http://localhost:8011
HOTEL_API_BASE=http://localhost:8011
EOF

# 3. 앱 서버 재시작
pkill -f "php -S localhost:8010"
php -S localhost:8010 -t public public/index.php &

# 4. 로그인 다시 시도
```

**프로덕션 환경:**

```bash
# 1. .env 파일 확인
cat /home/yourapp/live/.env

# 2. HTTPS 접근 가능한지 테스트
curl -X POST https://nirvana835.mycafe24.com/api2/agency-sub-accounts/login \
  -H "Content-Type: application/json" \
  -d '{"login_id":"your_id","password":"your_password"}'

# 3. SSL 인증서 확인
openssl s_client -connect nirvana835.mycafe24.com:443

# 4. 방화벽 확인
# 필요시 포트 443 개방 확인
```

---

### 문제 3: 부계정으로 로그인은 되는데 이전 계정 정보가 보임

#### 증상
nirvana_sub1로 로그인했는데 다른 사용자 정보가 표시됨

#### 원인
1. 브라우저 캐시 문제
2. 세션이 제대로 초기화되지 않음
3. localStorage에 이전 데이터가 남아있음

#### 해결 방법

```javascript
// 브라우저 개발자 도구 (F12) → Console
// 다음 명령어 실행

// 1. localStorage 초기화
localStorage.clear();

// 2. sessionStorage 초기화
sessionStorage.clear();

// 3. 페이지 새로고침
location.reload();
```

또는 개발자 도구에서:
1. Application 탭
2. Storage → Local Storage → 사이트 선택
3. 모든 항목 삭제
4. 페이지 새로고침

---

## 🏨 호텔 API 관련 문제

---

### 문제 4: 호텔 목록이 로드되지 않음

#### 증상
"호텔 목록을 불러올 수 없습니다" 에러 또는 빈 목록

#### 원인
1. 세션이 없음 (로그인하지 않음)
2. HOTEL_API_BASE가 설정되지 않음
3. 외부 API가 응답하지 않음

#### 해결 방법

**Step 1: 로그인 확인**

```javascript
// 브라우저 콘솔에서
console.log(localStorage.getItem('user'));
```

로그인 정보가 없으면 먼저 로그인

**Step 2: 호텔 API 테스트**

```bash
# 로그인
curl -X POST http://localhost:8010/api/agency-login \
  -H "Content-Type: application/json" \
  -d '{"login_id":"nirvana_sub1","password":"password123"}' \
  -c /tmp/cookies.txt

# 호텔 목록 조회
curl http://localhost:8010/api/hotels \
  -b /tmp/cookies.txt
```

**Step 3: 서버 로그 확인**

```bash
# PHP 에러 로그 확인
tail -f /tmp/error_log

# 또는 사용자 정의 로그
grep "HOTEL" ~/.php/error_log
```

**Step 4: .env 설정 확인**

```bash
# HOTEL_API_BASE 확인
grep HOTEL_API_BASE .env*

# 없으면 추가
echo "HOTEL_API_BASE=http://localhost:8011" >> .env.local
```

---

### 문제 5: "호텔 상세 정보를 불러올 수 없습니다"

#### 증상
호텔 목록은 보이는데 호텔 클릭 시 상세 정보가 안 나옴

#### 원인
1. 존재하지 않는 호텔 ID
2. Mock API 서버에 상세 데이터가 없음
3. 네트워크 에러

#### 해결 방법

```bash
# 호텔 ID 확인
curl http://localhost:8010/api/hotels -b /tmp/cookies.txt | jq '.hotels[].idx'

# 호텔 상세 요청 테스트
curl http://localhost:8010/api/hotels/1 -b /tmp/cookies.txt

# Mock API 직접 확인
curl -X POST http://localhost:8011/api2/hotels/1 \
  -H "Content-Type: application/json" \
  -d '{}'
```

---

## 🏢 에이전시 API 관련 문제

---

### 문제 6: 에이전시 정보가 표시되지 않음

#### 증상
폼에서 에이전시 명 등 정보가 비어있음

#### 원인
1. 부계정으로 로그인하지 않음 (일반 에이전트로만 로그인)
2. 부계정에 agency 정보가 없음
3. API 응답에 agency 필드가 누락됨

#### 해결 방법

**Step 1: 로그인 방식 확인**

```javascript
// 브라우저 콘솔에서 로그인된 사용자 확인
console.log(JSON.parse(localStorage.getItem('user')));

// agency 필드 확인
// { id: 3, name: "...", agency: {...} } 형태여야 함
```

**Step 2: 부계정으로 로그인 확인**

```bash
# 올바른 부계정으로 로그인
curl -X POST http://localhost:8010/api/agency-login \
  -H "Content-Type: application/json" \
  -d '{"login_id":"nirvana_sub1","password":"password123"}'

# 응답에 agency 필드가 있는지 확인
# "agency": {"idx": 2, "kind": "travel", ...}
```

**Step 3: 데이터베이스 확인**

```bash
# MySQL에서 사용자 정보 확인
mysql -u root -p
> SELECT * FROM users WHERE login_id='nirvana_sub1';
> SELECT * FROM user_agencies WHERE user_id=3;
```

---

### 문제 7: "에이전시 목록을 불러올 수 없습니다"

#### 증상
에이전시 목록 페이지가 로드되지 않음

#### 원인
1. HOTEL_API_BASE 설정 누락
2. 외부 API 응답 안 함
3. 세션 만료

#### 해결 방법

```bash
# 에이전시 목록 API 테스트
curl http://localhost:8010/api/agencies \
  -b /tmp/cookies.txt

# Mock API 직접 테스트
curl -X POST http://localhost:8011/api2/agencies \
  -H "Content-Type: application/json" \
  -d '{}'
```

---

## 📱 브라우저 관련 문제

---

### 문제 8: "localhost refused to connect" 또는 ERR_CONNECTION_REFUSED

#### 증상
http://localhost:8010 접속 불가

#### 원인
1. PHP 서버가 실행 중이 아님
2. 포트 8010이 이미 사용 중
3. 방화벽이 차단함

#### 해결 방법

**Step 1: 서버 프로세스 확인**

```bash
# 실행 중인 PHP 서버 확인
ps aux | grep "php -S"

# 또는 포트 확인
lsof -i :8010
```

**Step 2: 서버 재시작**

```bash
# 기존 프로세스 종료
pkill -f "php -S localhost:8010"

# 서버 재시작
cd /home/claude/live
php -S localhost:8010 -t public public/index.php &

# 로그 확인
tail -f /tmp/php-server.log
```

**Step 3: 포트 변경 (충돌 시)**

```bash
# 다른 포트로 실행
php -S localhost:8080 -t public public/index.php &

# 브라우저에서 http://localhost:8080 접속
```

---

### 문제 9: CORS 에러

#### 증상
브라우저 콘솔: "Access to XMLHttpRequest has been blocked by CORS policy"

#### 원인
1. 로컬호스트 요청이 차단됨 (Chrome 정책)
2. 프론트엔드와 백엔드의 도메인/포트가 다름

#### 해결 방법

**개발 환경:**

```bash
# Chrome을 CORS 무시 모드로 실행
open -a Google\ Chrome --args --disable-web-security --user-data-dir=/tmp/chrome
```

또는 다른 브라우저 사용:
- Firefox (로컬호스트는 CORS 무시)
- Safari
- Edge

**프로덕션 환경:**

```php
// src/lib.php의 cors() 함수에서 헤더 추가
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
```

---

## 🗄️ 데이터베이스 관련 문제

---

### 문제 10: "database connection failed"

#### 증상
"데이터베이스에 연결할 수 없습니다" 에러

#### 원인
1. MySQL 서버가 실행 중이 아님
2. 연결 정보가 잘못됨
3. 권한 문제

#### 해결 방법

```bash
# 1. MySQL 상태 확인
sudo systemctl status mysql
# 또는
sudo service mysql status

# 2. MySQL 시작
sudo systemctl start mysql
# 또는
sudo service mysql start

# 3. 연결 정보 확인
cat .env | grep DB

# 4. 직접 연결 테스트
mysql -u root -p -e "SELECT 1;"

# 5. 데이터베이스 확인
mysql -u root -p -e "SHOW DATABASES;"
```

---

### 문제 11: "table doesn't exist" 에러

#### 증상
"테이블을 찾을 수 없습니다" 에러

#### 원인
1. 데이터베이스가 초기화되지 않음
2. 테이블 구조가 다름

#### 해결 방법

```bash
# 데이터베이스 초기화 스크립트 실행
mysql -u root -p < docs/schema.sql

# 또는 수동으로
mysql -u root -p
> USE roomcheck;
> CREATE TABLE IF NOT EXISTS users (
>   id INT PRIMARY KEY AUTO_INCREMENT,
>   ...
> );
```

---

## 🔧 배포 관련 문제

---

### 문제 12: SSH 배포 실패

#### 증상
"ssh: connect to host ... refused" 또는 "Permission denied"

#### 원인
1. SSH 서버가 실행 중이 아님
2. SSH 키가 없거나 권한이 잘못됨
3. 호스트명/IP가 잘못됨

#### 해결 방법

```bash
# 1. SSH 연결 테스트
ssh -v user@your-domain.com

# 2. SSH 키 권한 확인
chmod 600 ~/.ssh/id_rsa
chmod 644 ~/.ssh/id_rsa.pub

# 3. SSH 키 생성 (없는 경우)
ssh-keygen -t rsa -b 4096 -f ~/.ssh/id_rsa -N ""

# 4. 공개키 서버에 복사
ssh-copy-id -i ~/.ssh/id_rsa.pub user@your-domain.com

# 5. 다시 연결 시도
ssh user@your-domain.com
```

---

### 문제 13: .env 파일 배포 누락

#### 증상
프로덕션에서 "agency_disabled" 에러

#### 원인
.env 파일이 배포되지 않음 (보안상 .gitignore 대상)

#### 해결 방법

**SCP로 수동 배포:**

```bash
# .env 파일만 따로 복사
scp .env user@your-domain.com:/home/yourapp/live/

# 권한 설정
ssh user@your-domain.com "chmod 600 /home/yourapp/live/.env"
```

**또는 Git 배포 후 수동으로 설정:**

```bash
# SSH로 접속
ssh user@your-domain.com

# .env 파일 생성
cat > /home/yourapp/live/.env << EOF
AGENCY_API_BASE=https://nirvana835.mycafe24.com
AGENCY_API_PATH=/api2/agency-sub-accounts/login
AGENCY_API_MODE=json
AGENCY_API_TIMEOUT=10
HOTEL_API_BASE=https://nirvana835.mycafe24.com
HOTEL_API_PATH=/api2/hotels
HOTEL_API_TIMEOUT=10
EOF

# 권한 설정
chmod 600 /home/yourapp/live/.env
```

---

### 문제 14: GitHub Actions 배포 실패

#### 증상
"workflow run failed"

#### 원인
1. SSH 자격증명이 잘못됨
2. SSH 키가 저장되지 않음
3. 호스트 키 확인 실패

#### 해결 방법

```bash
# 1. SSH 키 생성 (로컬)
ssh-keygen -t rsa -b 4096 -f /tmp/deploy_key -N ""

# 2. 공개키를 서버에 추가
cat /tmp/deploy_key.pub >> ~/.ssh/authorized_keys

# 3. 개인키를 GitHub Secrets에 추가
cat /tmp/deploy_key | tr '\n' '|'  # 한 줄 텍스트로 변환
# SSH_KEY secret에 붙여넣기

# 4. .github/workflows/deploy.yml 확인
cat .github/workflows/deploy.yml | grep -A 10 "ssh-action"
```

---

## 📊 성능 관련 문제

---

### 문제 15: 응답이 느림 (>5초)

#### 증상
페이지 로드가 5초 이상 걸림

#### 원인
1. 외부 API 응답이 느림
2. 데이터베이스 쿼리가 비효율적
3. 네트워크 지연

#### 진단 방법

```bash
# API 응답 시간 측정
time curl http://localhost:8010/api/hotels -b /tmp/cookies.txt

# 상세 타이밍 정보
curl -w "
Time taken for different operations:
    namelookup:  %{time_namelookup}
    connect:     %{time_connect}
    appconnect:  %{time_appconnect}
    pretransfer: %{time_pretransfer}
    redirect:    %{time_redirect}
    starttransfer: %{time_starttransfer}
    total:       %{time_total}
" http://localhost:8010/api/hotels -b /tmp/cookies.txt
```

#### 해결 방법

```php
// src/lib.php에서 성능 로깅 추가
$start = microtime(true);

// API 호출 코드...

$elapsed = microtime(true) - $start;
error_log("Hotel API took: " . $elapsed . " seconds");
```

---

## 🔍 디버깅 팁

---

### 일반적인 디버깅 방법

**1. 서버 로그 확인**

```bash
# PHP 에러 로그
tail -f /var/log/php/error.log

# Apache 에러 로그
tail -f /var/log/apache2/error.log

# 접근 로그
tail -f /var/log/apache2/access.log
```

**2. 브라우저 개발자 도구**

- F12 열기
- Network 탭: HTTP 요청/응답 확인
- Console 탭: JavaScript 에러 확인
- Application 탭: 로컬스토리지/세션 확인

**3. Curl 디버깅**

```bash
# 상세 정보 출력
curl -v http://localhost:8010/api/hotels

# 헤더만 확인
curl -I http://localhost:8010/api/hotels

# JSON 포맷팅
curl http://localhost:8010/api/hotels | jq .
```

---

## 📞 지원 연락처

문제를 해결할 수 없는 경우:

1. 이 문서의 모든 해결 방법 시도
2. 서버 로그 확인
3. `docs/API_DOCUMENTATION.md`에서 API 스펙 재확인
4. `docs/DEPLOYMENT_METHODS.md`에서 배포 절차 재확인

---

**작성자:** Claude  
**최종 업데이트:** 2026-07-24  
**상태:** ✅ 완료
