<?php
/**
 * Mock API 서버 - 에이전시 부계정 + 호텔 API 시뮬레이션
 * 실행: php mock-api-server.php
 * 또는: php -S localhost:8011
 */

header('Content-Type: application/json; charset=utf-8');

$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$query = parse_url($_SERVER['REQUEST_URI'], PHP_URL_QUERY);

error_log("MOCK: $method $path");

// POST 본문 읽기
$input = json_decode(file_get_contents('php://input'), true) ?? [];

// 부계정 로그인
if ($path === '/api2/agency-sub-accounts/login' && $method === 'POST') {
    $loginId = $input['login_id'] ?? '';
    $password = $input['password'] ?? '';

    // 테스트 계정 (스크린샷 참고)
    $testAccounts = [
        'nirvana_sub1' => ['name' => '너비나서브1', 'nickname' => 'nirvana_sub1'],
        'sub1' => ['name' => '서브1', 'nickname' => 'sub1'],
        'test1234' => ['name' => 'test', 'nickname' => 'test'],
        'test2' => ['name' => '이지성', 'nickname' => '지성'],
        'nirvana_sub1' => ['name' => '너비나서브1', 'nickname' => 'nirvana_sub1', 'agency' => 'The Nirvana'],
    ];

    if (isset($testAccounts[$loginId]) && $password === 'password123') {
        $account = $testAccounts[$loginId];
        echo json_encode([
            'success' => true,
            'message' => '인증 성공',
            'data' => [
                'idx' => 2,
                'parent_idx' => null,
                'kind' => 'travel',
                'login_id' => $loginId,
                'name' => $account['name'],
                'nickname' => $account['nickname'],
            ]
        ]);
        exit;
    } else {
        http_response_code(401);
        echo json_encode([
            'success' => false,
            'message' => '아이디 또는 비밀번호가 일치하지 않습니다'
        ]);
        exit;
    }
}

// 호텔 목록
if ($path === '/api2/hotels' && $method === 'POST') {
    $hotels = [
        [
            'idx' => 1,
            'name' => 'The Nirvana',
            'main_hotel_yn' => 'Y',
            'area' => 'Bangkok',
            'address' => '...',
        ],
        [
            'idx' => 2,
            'name' => 'Test Hotel',
            'main_hotel_yn' => 'N',
            'area' => 'Krabi',
            'address' => '...',
        ],
        [
            'idx' => 3,
            'name' => 'Dr Travel',
            'main_hotel_yn' => 'N',
            'area' => 'Bangkok',
            'address' => '...',
        ],
    ];

    echo json_encode([
        'success' => true,
        'message' => '호텔 목록 조회 성공',
        'data' => $hotels
    ]);
    exit;
}

// 호텔 상세
if (preg_match('/^\/api2\/hotels\/(\d+)$/', $path, $m) && $method === 'POST') {
    $hotelId = (int)$m[1];

    $hotels = [
        1 => [
            'hotel' => [
                'idx' => 1,
                'name' => 'The Nirvana',
                'main_hotel_yn' => 'Y',
            ],
            'room_types' => [
                ['idx' => 101, 'name' => '디럭스룸', 'code' => 'DELUXE'],
                ['idx' => 102, 'name' => '스위트룸', 'code' => 'SUITE'],
            ],
            'facilities' => ['WiFi', 'Pool', 'Restaurant'],
        ],
        2 => [
            'hotel' => [
                'idx' => 2,
                'name' => 'Test Hotel',
            ],
            'room_types' => [
                ['idx' => 201, 'name' => '스탠다드룸', 'code' => 'STANDARD'],
            ],
            'facilities' => ['WiFi'],
        ],
    ];

    if (isset($hotels[$hotelId])) {
        echo json_encode([
            'success' => true,
            'message' => '호텔 상세 조회 성공',
            'data' => $hotels[$hotelId]
        ]);
    } else {
        http_response_code(404);
        echo json_encode([
            'success' => false,
            'message' => '호텔을 찾을 수 없습니다'
        ]);
    }
    exit;
}

// 에이전시 목록
if ($path === '/api2/agencies' && $method === 'POST') {
    echo json_encode([
        'success' => true,
        'message' => '에이전시 목록 조회 성공',
        'data' => [
            [
                'idx' => 1,
                'name' => 'Awesome Agency',
                'type' => 'travel',
                'level' => 1,
            ],
            [
                'idx' => 2,
                'name' => 'The Nirvana',
                'type' => 'travel',
                'level' => 1,
            ],
        ]
    ]);
    exit;
}

// 에이전시 상세
if (preg_match('/^\/api2\/agencies\/(\d+)$/', $path, $m) && $method === 'POST') {
    $agencyId = (int)$m[1];

    $agencies = [
        1 => [
            'agency' => [
                'idx' => 1,
                'name' => 'Awesome Agency',
                'type' => 'travel',
                'level' => 1,
                'phone' => '02-1234-5678',
                'email' => 'info@awesome.com',
            ],
            'managers' => [
                ['name' => '홍길동', 'position' => '대표', 'phone' => '010-1111-1111'],
            ],
            'bank_accounts' => [
                ['bank' => '국민은행', 'account' => '123-456-789012', 'holder' => 'Awesome Agency'],
            ],
            'contracts' => [
                ['idx' => 101, 'name' => '계약1', 'status' => 'active'],
            ],
        ],
        2 => [
            'agency' => [
                'idx' => 2,
                'name' => 'The Nirvana',
                'type' => 'travel',
                'level' => 1,
                'phone' => '02-9999-8888',
                'email' => 'info@nirvana.com',
            ],
            'managers' => [
                ['name' => '김영희', 'position' => '대표', 'phone' => '010-2222-2222'],
                ['name' => '이순신', 'position' => '부대표', 'phone' => '010-3333-3333'],
            ],
            'bank_accounts' => [
                ['bank' => '신한은행', 'account' => '987-654-321098', 'holder' => 'The Nirvana'],
            ],
            'contracts' => [
                ['idx' => 201, 'name' => '계약2', 'status' => 'active'],
                ['idx' => 202, 'name' => '계약3', 'status' => 'inactive'],
            ],
        ],
    ];

    if (isset($agencies[$agencyId])) {
        echo json_encode([
            'success' => true,
            'message' => '에이전시 상세 조회 성공',
            'data' => $agencies[$agencyId]
        ]);
    } else {
        http_response_code(404);
        echo json_encode([
            'success' => false,
            'message' => '에이전시를 찾을 수 없습니다'
        ]);
    }
    exit;
}

// 404
http_response_code(404);
echo json_encode(['error' => 'not_found']);
