<?php
/* ===== DB 연결 + 스키마 (SQLite 개발 / MySQL 운영) ===== */
function env(string $k, ?string $d = null): ?string {
  $v = getenv($k);
  return ($v === false || $v === '') ? $d : $v;
}
function db(): PDO {
  static $pdo = null;
  if ($pdo) return $pdo;
  $dsn = env('DB_DSN', 'sqlite:' . __DIR__ . '/../data/roomcheck.sqlite');
  $pdo = new PDO($dsn, env('DB_USER'), env('DB_PASS'), [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);
  if (str_starts_with($dsn, 'sqlite:')) $pdo->exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=3000;');
  migrate($pdo);
  return $pdo;
}
function isMySQL(PDO $pdo): bool { return $pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql'; }

function migrate(PDO $pdo): void {
  $my = isMySQL($pdo);
  $AI = $my ? 'BIGINT AUTO_INCREMENT PRIMARY KEY' : 'INTEGER PRIMARY KEY AUTOINCREMENT';
  $TXT = $my ? 'LONGTEXT' : 'TEXT';
  $pdo->exec("CREATE TABLE IF NOT EXISTS users (
    id $AI,
    name VARCHAR(80) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    pass_hash VARCHAR(255) NOT NULL,
    role VARCHAR(10) NOT NULL,               -- agent | sreq | schk | admin
    status VARCHAR(10) NOT NULL DEFAULT 'pending',  -- pending | approved | rejected
    lang VARCHAR(5) NOT NULL DEFAULT 'ko',
    telegram_chat_id VARCHAR(40) NULL,
    tg_link_code VARCHAR(40) NULL,
    notif_read_at BIGINT NOT NULL DEFAULT 0,
    created_at BIGINT NOT NULL
  )");
  $pdo->exec("CREATE TABLE IF NOT EXISTS requests (
    id BIGINT PRIMARY KEY,                   -- 클라이언트 생성 id (Date.now())
    no INT NOT NULL,
    payload $TXT NOT NULL,                   -- 전체 요청 JSON
    deleted TINYINT NOT NULL DEFAULT 0,
    updated_at BIGINT NOT NULL,
    updated_by BIGINT NULL
  )");
  $pdo->exec("CREATE TABLE IF NOT EXISTS meta (
    k VARCHAR(40) PRIMARY KEY,
    v $TXT NOT NULL
  )");
  $pdo->exec("CREATE TABLE IF NOT EXISTS notifications (
    id $AI,
    role VARCHAR(10) NOT NULL,               -- 대상 역할
    exclude_user BIGINT NULL,                -- 행동 당사자 (본인 제외)
    type VARCHAR(30) NOT NULL,
    req_no VARCHAR(12) NULL,
    params $TXT NULL,
    created_at BIGINT NOT NULL
  )");
  // 최초 관리자 계정
  $n = $pdo->query("SELECT COUNT(*) c FROM users WHERE role='admin'")->fetch()['c'];
  if ((int)$n === 0) {
    $st = $pdo->prepare("INSERT INTO users (name,email,pass_hash,role,status,lang,created_at) VALUES (?,?,?,?,?,?,?)");
    $st->execute(['관리자', env('ADMIN_EMAIL', 'admin@nirvana.local'),
      password_hash(env('ADMIN_PASSWORD', 'nirvana1234!'), PASSWORD_DEFAULT),
      'admin', 'approved', 'ko', (int)(microtime(true) * 1000)]);
  }
}
function metaGet(PDO $pdo, string $k, $default) {
  $st = $pdo->prepare("SELECT v FROM meta WHERE k=?"); $st->execute([$k]);
  $r = $st->fetch();
  return $r ? json_decode($r['v'], true) : $default;
}
function metaSet(PDO $pdo, string $k, $v): void {
  $j = json_encode($v, JSON_UNESCAPED_UNICODE);
  if (isMySQL($pdo)) {
    $st = $pdo->prepare("INSERT INTO meta (k,v) VALUES (?,?) ON DUPLICATE KEY UPDATE v=VALUES(v)");
  } else {
    $st = $pdo->prepare("INSERT INTO meta (k,v) VALUES (?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v");
  }
  $st->execute([$k, $j]);
}
function bumpRev(PDO $pdo): int {
  $rev = (int)metaGet($pdo, 'rev', 0) + 1;
  metaSet($pdo, 'rev', $rev);
  return $rev;
}
function nowMs(): int { return (int)(microtime(true) * 1000); }
