<?php
/* ===== 이벤트 감지 → 인앱 알림 + 텔레그램 ===== */
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/telegram.php';

function notify(PDO $pdo, array $roles, ?int $actor, string $type, string $reqNo, array $params = []): void {
  $st = $pdo->prepare("INSERT INTO notifications (role,exclude_user,type,req_no,params,created_at) VALUES (?,?,?,?,?,?)");
  foreach (array_unique($roles) as $role) {
    $st->execute([$role, $actor, $type, $reqNo, json_encode($params, JSON_UNESCAPED_UNICODE), nowMs()]);
    // 텔레그램 즉시 전송 (sreq/schk만 — tgSendRole 내부에서 필터)
    tgSendRole($pdo, $role, fn($lang) => tgT($lang, $type, array_merge($params, ['no' => $reqNo])), $actor);
  }
}

/* 요청 upsert 시 old/new payload를 비교해 이벤트 발생 */
function detectEvents(PDO $pdo, ?array $old, array $new, array $actor): void {
  $no = reqNoStr($new);
  $hotels = reqHotels($new);
  $role = $actor['role'];
  $uid = (int)$actor['id'];

  // 1) 새 요청 (직접 등록 제외 → 확인자에게 / 에이전트가 만들면 요청자에게도)
  if ($old === null && empty($new['direct'])) {
    $targets = ['schk'];
    if ($role === 'agent') $targets[] = 'sreq';
    notify($pdo, $targets, $uid, 'new_request', $no, ['hotels' => $hotels, 'dates' => reqDates($new), 'agent' => $new['agent'] ?? '']);
    return;
  }
  if ($old === null) return; // 직접 등록은 알림 없음

  // 2) 답변 도착 / 부분 답변 (answeredAt 갱신)
  $oldAns = $old['answeredAt'] ?? null;
  $newAns = $new['answeredAt'] ?? null;
  if ($newAns && $newAns !== $oldAns && $role === 'schk') {
    $rows = count($new['rows'] ?? []);
    $doneRows = 0;
    foreach (($new['rows'] ?? []) as $r) {
      // answerComplete 필드로 전체 완료 판단, 행 단위는 클라이언트 계산이므로 근사치
      $doneRows++;
    }
    if (!empty($new['answerComplete'])) {
      notify($pdo, ['sreq', 'agent'], $uid, 'answered', $no, ['hotels' => $hotels]);
    } else {
      notify($pdo, ['sreq'], $uid, 'partial', $no, ['n' => $new['_doneCount'] ?? '?', 't' => $rows, 'hotels' => $hotels]);
    }
  }

  // 3) 견적 요청됨 (에이전트 → 요청자)
  if (empty($old['quoteRequested']) && !empty($new['quoteRequested']) && empty($new['quoteSent'])) {
    notify($pdo, ['sreq'], $uid, 'quote_requested', $no, ['hotels' => $hotels]);
  }

  // 4) 견적 발송됨 (요청자 → 에이전트, 인앱만: tgSendRole이 agent를 걸러줌)
  if (empty($old['quoteSent']) && !empty($new['quoteSent'])) {
    notify($pdo, ['agent'], $uid, 'quote_sent', $no, ['hotels' => $hotels]);
  }
}
