<?php
/* ===== 공용 헬퍼: 세션, 응답, 권한 ===== */
require_once __DIR__ . '/db.php';

function startSession(): void {
  if (session_status() === PHP_SESSION_ACTIVE) return;
  session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax',
    'secure' => (($_SERVER['HTTPS'] ?? '') !== '' || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')]);
  session_name('rc_session');
  session_start();
}
function jsonOut($data, int $code = 200): never {
  http_response_code($code);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode($data, JSON_UNESCAPED_UNICODE);
  exit;
}
function jsonIn(): array {
  $raw = file_get_contents('php://input');
  $j = json_decode($raw ?: 'null', true);
  return is_array($j) ? $j : [];
}
function currentUser(): ?array {
  startSession();
  $uid = $_SESSION['uid'] ?? null;
  if (!$uid) return null;
  $st = db()->prepare("SELECT id,name,email,role,status,lang,telegram_chat_id,notif_read_at FROM users WHERE id=?");
  $st->execute([$uid]);
  $u = $st->fetch();
  return $u ?: null;
}
function requireApproved(): array {
  $u = currentUser();
  if (!$u) jsonOut(['error' => 'unauthenticated'], 401);
  if ($u['status'] !== 'approved') jsonOut(['error' => 'pending'], 403);
  return $u;
}
function requireAdmin(): array {
  $u = requireApproved();
  if ($u['role'] !== 'admin') jsonOut(['error' => 'forbidden'], 403);
  return $u;
}
function publicUser(?array $u): ?array {
  if (!$u) return null;
  return ['id' => (int)$u['id'], 'name' => $u['name'], 'email' => $u['email'],
    'role' => $u['role'], 'status' => $u['status'], 'lang' => $u['lang'],
    'tg' => !empty($u['telegram_chat_id'])];
}
/* 요청 payload에서 표시용 요약 추출 */
function reqNoStr(array $p): string { return 'R-' . str_pad((string)($p['no'] ?? 0), 3, '0', STR_PAD_LEFT); }
function reqHotels(array $p): string {
  $names = array_map(fn($r) => $r['hotel'] ?: '-', $p['rows'] ?? []);
  return implode(' · ', array_slice($names, 0, 4));
}
function reqDates(array $p): string {
  $rows = $p['rows'] ?? [];
  if (!$rows) return '';
  return ($p['startDate'] ?? '') . ' ~';
}
/* 미처리 판정: 확인자 기준(요청됨 또는 부분답변), 요청자 기준(견적 요청됨 미발송) */
function isPendingForChecker(array $p): bool {
  if (!empty($p['direct'])) return false;
  if (($p['status'] ?? '') === 'requested') return true;
  return ($p['status'] ?? '') === 'answered' && empty($p['answerComplete']);
}
function isPendingForRequester(array $p): bool {
  return !empty($p['quoteRequested']) && empty($p['quoteSent']);
}
function allRequests(PDO $pdo): array {
  $out = [];
  foreach ($pdo->query("SELECT payload FROM requests WHERE deleted=0")->fetchAll() as $r) {
    $p = json_decode($r['payload'], true);
    if ($p) $out[] = $p;
  }
  return $out;
}
