<?php
/* ===== API 라우터 ===== */
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/events.php';
require_once __DIR__ . '/digest.php';

function route(string $path, string $method): void {
  $pdo = db();
  $in = jsonIn();

  /* ---------- 인증 ---------- */
  if ($path === 'register' && $method === 'POST') {
    $name = trim($in['name'] ?? ''); $email = strtolower(trim($in['email'] ?? ''));
    $pw = $in['password'] ?? ''; $role = $in['role'] ?? ''; $lang = $in['lang'] ?? 'ko';
    if (!$name || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($pw) < 6) jsonOut(['error' => 'invalid_input'], 422);
    if (!in_array($role, ['agent', 'sreq', 'schk'], true)) jsonOut(['error' => 'invalid_role'], 422);
    $allowed = ['agent' => ['ko'], 'sreq' => ['en', 'ko'], 'schk' => ['th', 'en']][$role];
    if (!in_array($lang, $allowed, true)) $lang = $allowed[0];
    try {
      $st = $pdo->prepare("INSERT INTO users (name,email,pass_hash,role,status,lang,created_at) VALUES (?,?,?,?, 'pending', ?,?)");
      $st->execute([$name, $email, password_hash($pw, PASSWORD_DEFAULT), $role, $lang, nowMs()]);
    } catch (PDOException $e) { jsonOut(['error' => 'email_exists'], 409); }
    jsonOut(['ok' => true, 'pending' => true]);
  }
  if ($path === 'login' && $method === 'POST') {
    startSession();
    $st = $pdo->prepare("SELECT * FROM users WHERE email=?");
    $st->execute([strtolower(trim($in['email'] ?? ''))]);
    $u = $st->fetch();
    if (!$u || !password_verify($in['password'] ?? '', $u['pass_hash'])) jsonOut(['error' => 'bad_credentials'], 401);
    if ($u['status'] === 'rejected') jsonOut(['error' => 'rejected'], 403);
    if ($u['status'] !== 'approved') jsonOut(['error' => 'pending'], 403);
    session_regenerate_id(true);
    $_SESSION['uid'] = (int)$u['id'];
    jsonOut(['ok' => true, 'user' => publicUser($u)]);
  }
  if ($path === 'logout' && $method === 'POST') { startSession(); session_destroy(); jsonOut(['ok' => true]); }
  if ($path === 'me' && $method === 'GET') jsonOut(['user' => publicUser(currentUser())]);
  if ($path === 'me' && $method === 'PATCH') {
    $u = requireApproved();
    if (isset($in['lang'])) {
      $allowed = ['agent' => ['ko'], 'sreq' => ['en', 'ko'], 'schk' => ['th', 'en'], 'admin' => ['ko']][$u['role']];
      if (in_array($in['lang'], $allowed, true)) {
        $pdo->prepare("UPDATE users SET lang=? WHERE id=?")->execute([$in['lang'], $u['id']]);
      }
    }
    jsonOut(['ok' => true]);
  }

  /* ---------- 상태 폴링 ---------- */
  if ($path === 'state' && $method === 'GET') {
    $u = requireApproved();
    $rev = (int)metaGet($pdo, 'rev', 0);
    $since = (int)($_GET['rev'] ?? -1);
    $out = ['rev' => $rev];
    if ($since !== $rev) {
      $out['requests'] = allRequests($pdo);
      $out['phones'] = metaGet($pdo, 'phones', new stdClass());
      $out['fullbook'] = metaGet($pdo, 'fullbook', new stdClass());
      $out['seq'] = (int)metaGet($pdo, 'seq', 0);
    }
    // 알림 (역할 대상, 본인 행동 제외)
    $st = $pdo->prepare("SELECT type,req_no,params,created_at,exclude_user FROM notifications
      WHERE role=? AND (exclude_user IS NULL OR exclude_user<>?) ORDER BY id DESC LIMIT 20");
    $st->execute([$u['role'], $u['id']]);
    $items = [];
    $unread = 0;
    foreach ($st->fetchAll() as $n) {
      $it = ['type' => $n['type'], 'no' => $n['req_no'], 'p' => json_decode($n['params'] ?: '{}', true), 'at' => (int)$n['created_at']];
      if ((int)$n['created_at'] > (int)$u['notif_read_at']) { $it['new'] = true; $unread++; }
      $items[] = $it;
    }
    $out['notifs'] = ['unread' => $unread, 'items' => $items];
    jsonOut($out);
  }

  /* ---------- 데이터 동기화 ---------- */
  if ($path === 'sync' && $method === 'POST') {
    $u = requireApproved();
    $fixes = [];
    $changed = false;
    foreach (($in['requests'] ?? []) as $req) {
      if (!is_array($req) || empty($req['id'])) continue;
      $id = (int)$req['id'];
      $st = $pdo->prepare("SELECT payload FROM requests WHERE id=? AND deleted=0");
      $st->execute([$id]);
      $row = $st->fetch();
      $old = $row ? json_decode($row['payload'], true) : null;
      if ($old === null) {
        // 새 요청: no 중복 방지 (서버가 최종 결정)
        $seq = (int)metaGet($pdo, 'seq', 0) + 1;
        metaSet($pdo, 'seq', $seq);
        if (empty($req['no']) || $req['no'] != $seq) { $req['no'] = $seq; $fixes[] = ['id' => $id, 'no' => $seq]; }
        $pdo->prepare("INSERT INTO requests (id,no,payload,deleted,updated_at,updated_by) VALUES (?,?,?,0,?,?)")
            ->execute([$id, (int)$req['no'], json_encode($req, JSON_UNESCAPED_UNICODE), nowMs(), $u['id']]);
      } else {
        $pdo->prepare("UPDATE requests SET no=?, payload=?, updated_at=?, updated_by=? WHERE id=?")
            ->execute([(int)$req['no'], json_encode($req, JSON_UNESCAPED_UNICODE), nowMs(), $u['id'], $id]);
      }
      detectEvents($pdo, $old, $req, $u);
      $changed = true;
    }
    if (isset($in['phones']) && is_array($in['phones'])) { metaSet($pdo, 'phones', $in['phones']); $changed = true; }
    if (isset($in['fullbook']) && is_array($in['fullbook'])) { metaSet($pdo, 'fullbook', $in['fullbook']); $changed = true; }
    $rev = $changed ? bumpRev($pdo) : (int)metaGet($pdo, 'rev', 0);
    jsonOut(['ok' => true, 'rev' => $rev, 'fixes' => $fixes]);
  }
  if ($path === 'delete' && $method === 'POST') {
    $u = requireApproved();
    $ids = array_filter(array_map('intval', $in['ids'] ?? []));
    if ($ids) {
      $ph = implode(',', array_fill(0, count($ids), '?'));
      $pdo->prepare("UPDATE requests SET deleted=1, updated_at=? WHERE id IN ($ph)")
          ->execute(array_merge([nowMs()], $ids));
      bumpRev($pdo);
    }
    jsonOut(['ok' => true]);
  }
  if ($path === 'notif-read' && $method === 'POST') {
    $u = requireApproved();
    $pdo->prepare("UPDATE users SET notif_read_at=? WHERE id=?")->execute([nowMs(), $u['id']]);
    jsonOut(['ok' => true]);
  }

  /* ---------- 텔레그램 ---------- */
  if ($path === 'tg-link' && $method === 'GET') {
    $u = requireApproved();
    if (!in_array($u['role'], ['sreq', 'schk'], true)) jsonOut(['error' => 'role_not_allowed'], 403);
    $code = bin2hex(random_bytes(8));
    $pdo->prepare("UPDATE users SET tg_link_code=? WHERE id=?")->execute([$code, $u['id']]);
    $bot = env('TELEGRAM_BOT_USERNAME', '');
    jsonOut(['code' => $code, 'url' => $bot ? "https://t.me/$bot?start=$code" : null, 'linked' => !empty($u['telegram_chat_id'])]);
  }
  if ($path === 'tg-webhook' && $method === 'POST') {
    if (env('TELEGRAM_WEBHOOK_SECRET') &&
        ($_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN'] ?? '') !== env('TELEGRAM_WEBHOOK_SECRET')) jsonOut(['ok' => true]);
    $msg = $in['message'] ?? null;
    if ($msg && preg_match('/^\/start\s+([a-f0-9]{16})/', $msg['text'] ?? '', $m)) {
      $st = $pdo->prepare("SELECT id,name,lang FROM users WHERE tg_link_code=?");
      $st->execute([$m[1]]);
      if ($usr = $st->fetch()) {
        $chat = (string)($msg['chat']['id'] ?? '');
        $pdo->prepare("UPDATE users SET telegram_chat_id=?, tg_link_code=NULL WHERE id=?")->execute([$chat, $usr['id']]);
        tgSend($chat, tgT($usr['lang'] ?: 'ko', 'linked', ['name' => $usr['name']]));
      }
    }
    jsonOut(['ok' => true]);
  }

  /* ---------- 예약 다이제스트 (Cloud Scheduler 호출) ---------- */
  if ($path === 'cron' && in_array($method, ['GET', 'POST'], true)) {
    if (($_GET['key'] ?? '') !== env('CRON_KEY', 'change-me')) jsonOut(['error' => 'forbidden'], 403);
    jsonOut(runDigest($pdo, $_GET['job'] ?? ''));
  }

  /* ---------- 관리자 ---------- */
  if ($path === 'admin/users' && $method === 'GET') {
    requireAdmin();
    $rows = $pdo->query("SELECT id,name,email,role,status,lang,telegram_chat_id,created_at FROM users ORDER BY status='pending' DESC, id DESC")->fetchAll();
    foreach ($rows as &$r) { $r['tg'] = !empty($r['telegram_chat_id']); unset($r['telegram_chat_id']); }
    jsonOut(['users' => $rows]);
  }
  if ($path === 'admin/decide' && $method === 'POST') {
    $admin = requireAdmin();
    $id = (int)($in['id'] ?? 0);
    $action = $in['action'] ?? '';
    if (!$id || !in_array($action, ['approve', 'reject', 'delete'], true)) jsonOut(['error' => 'invalid'], 422);
    if ($id === (int)$admin['id']) jsonOut(['error' => 'self'], 422);
    if ($action === 'delete') $pdo->prepare("DELETE FROM users WHERE id=? AND role<>'admin'")->execute([$id]);
    else $pdo->prepare("UPDATE users SET status=? WHERE id=? AND role<>'admin'")
             ->execute([$action === 'approve' ? 'approved' : 'rejected', $id]);
    jsonOut(['ok' => true]);
  }

  jsonOut(['error' => 'not_found', 'path' => $path], 404);
}
